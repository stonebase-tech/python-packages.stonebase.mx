import fire

from .cli import CLI


if __name__ == "__main__":
    fire.Fire(CLI())
